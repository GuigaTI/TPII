    package br.edu.fatecpg.aplicacaoJpa.model;

    import br.edu.fatecpg.aplicacaoJpa.controller.buscaEndereco;

    import com.google.gson.annotations.SerializedName;

    import com.google.gson.Gson;
    import java.io.IOException;
    import java.sql.SQLException;
    import java.util.Scanner;
    public class Endereco {
        private String cep;
        @SerializedName("logradouro")
        private String rua;
        private String bairro;
        @SerializedName("localidade")
        private String cidade;
        private String uf;
        public Endereco(String cep, String rua, String bairro, String cidade, String uf) {
            this.cep = cep;
            this.rua = rua;
            this.bairro = bairro;
            this.cidade = cidade;
            this.uf = uf;
        }


        public static void adicionaBanco(EnderecoBanco enderecoBanco) throws SQLException, IOException, InterruptedException {
            Gson gson = new Gson();
            Scanner scan = new Scanner(System.in);
            System.out.println("Digite o cep a ser buscado");
            String json = buscaEndereco.consomeApi(scan.nextLine());
            Endereco endereco = gson.fromJson(json,Endereco.class);
            enderecoBanco.addBanco(endereco);
        }

        @Override
        public String toString() {
            return "ENDEREÇO" +
                    "\nCEP: " + cep +
                    "\nRUA: " + rua +
                    "\nBAIRRO: " + bairro +
                    "\nCIDADE: " + cidade +
                    "\nUF: " + uf;
        }




        public String getCep() {
            return cep;
        }

        public void setCep(String cep) {
            this.cep = cep;
        }

        public String getRua() {
            return rua;
        }

        public void setRua(String rua) {
            this.rua = rua;
        }

        public String getBairro() {
            return bairro;
        }

        public void setBairro(String bairro) {
            this.bairro = bairro;
        }

        public String getCidade() {
            return cidade;
        }

        public void setCidade(String cidade) {
            this.cidade = cidade;
        }

        public String getUf() {
            return uf;
        }

        public void setUf(String uf) {
            this.uf = uf;
        }
    }