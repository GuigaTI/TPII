package br.edu.fatecpg.aplicacaoJpa;

import br.edu.fatecpg.aplicacaoJpa.model.Endereco;
import br.edu.fatecpg.aplicacaoJpa.model.EnderecoBanco;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;


@SpringBootApplication
public class AplicacaoJpaApplication implements CommandLineRunner {

	@Autowired
	private EnderecoBanco enderecoBanco;

	public static void main(String[] args) {
		SpringApplication.run(AplicacaoJpaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Scanner scanOP1 = new Scanner(System.in);
		int menu = 1;
		while (menu != 0) {
			System.out.println("Digite uma opção" + "\n" +
					"1 - Consultar cep" + " \n" +
					"2 - Ver CEPs Banco" + "\n" +
					"- Digite 0 para sair - " + "\n" +
					"-----------------------------------");
			int opM = scanOP1.nextInt();
			switch (opM) {
				case 1:
					Endereco.adicionaBanco(enderecoBanco);
					break;
				case 2:
					enderecoBanco.consultaBanco();
					break;
				case 0:
					menu = 0;
					System.out.println("Programa encerrado!!!!!");
					break;
				default:
					System.out.println("Digite uma opção valida");
					break;

			}
		}
	}
}
