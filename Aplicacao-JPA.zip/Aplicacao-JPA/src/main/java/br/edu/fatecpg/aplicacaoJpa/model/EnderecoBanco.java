package br.edu.fatecpg.aplicacaoJpa.model;

import br.edu.fatecpg.aplicacaoJpa.repository.EnderecoBancoRepository;
import jakarta.persistence.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.List;




@Entity
@Table(name = "ceps")
@Component
public class EnderecoBanco {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true)
    private String cep;
    @Column(name="ruaCompleta")
    private String rua;
    @Column(name="bairro")
    private String bairro;
    @Column(name="cidade")
    private String cidade;
    @Column(name="estado")
    private String uf;
    private final EnderecoBancoRepository repository;
    @Autowired
    public EnderecoBanco(EnderecoBancoRepository repository) {
        this.repository = repository;
    }


    public EnderecoBanco(String cep, String rua, String bairro, String cidade, String uf, EnderecoBancoRepository repository) {
        this.cep = cep;
        this.rua = rua;
        this.bairro = bairro;
        this.cidade = cidade;
        this.uf = uf;
        this.repository = repository;
    }
    public EnderecoBanco(Endereco endereco, EnderecoBancoRepository repository) {
        this.cep = endereco.getCep();
        this.rua = endereco.getRua();
        this.bairro = endereco.getBairro();
        this.cidade = endereco.getCidade();
        this.uf = endereco.getUf();
        this.repository = repository;
    }

    public void consultaBanco() throws SQLException {
        List<EnderecoBanco> enderecos = repository.findAll();
        enderecos.forEach(System.out::println);
    }
    public void addBanco(Endereco endereco){
        EnderecoBanco enderecoBanco = new EnderecoBanco(endereco);
        repository.save(enderecoBanco);

    }

    @Override
        public String toString() {
            return "ENDEREÇO" +
                    "\nCEP: " + cep +
                    "\nRUA: " + rua +
                    "\nBAIRRO: " + bairro +
                    "\nCIDADE: " + cidade +
                    "\nUF: " + uf;
        }

    public EnderecoBancoRepository getRepository() {
        return repository;
    }
}
